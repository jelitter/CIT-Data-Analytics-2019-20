from sR00156019 import task1, task2, task3, task4, task5, task6, task7, task8, task9, task10, task11, task12

print('\n\n----------------------------------------------')
print(' Isaac Sanchez - Second Assessment. Project-I')
print('----------------------------------------------\n')

# print('Running Task 1 ...')
# task1()

# print('Running Task 2 ...')
# task2()

# print('Running Task 3 ...')
# task3()

# print('Running Task 4 ...')
# task4()

# print('Running Task 5 ...')
# task5()

# print('Running Task 6 ...')
# task6()

# print('Running Task 7 ...')
# task7()

# print('Running Task 8 ...')
# task8()

# print('Running Task 9 ...')
# task9()

# print('Running Task 10 ...')
# task10()

# print('Running Task 11 ...')
# task11()

print('Running Task 12 ...')
task12()
